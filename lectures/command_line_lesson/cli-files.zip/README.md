The slides are available [here](https://docs.google.com/presentation/d/1ZhJnS_IbpU13nSH3fWMduN1alpDlooBOEV0y4tk62GM/edit?usp=sharing). (Warning to non-CCAC-affiliated folks: they're kind of customized for our computer classrooms.)

pgh_steps.txt came from the [Western Pennsylvania Regional Data Center](https://data.wprdc.org/dataset/city-steps).

A lot of the content in this directory is my own, but a lot of it is thanks to my friend and colleague [Eric Phetteplace](https://phette.net/), who co-designed and co-ran the [Code4Lib 2016 Command Line Bootcamp](https://github.com/csheldonhess/c4l16-cli-workshop) with me.