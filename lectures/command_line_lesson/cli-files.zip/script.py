''' Python 1 - DAT-119 - Spring 2019
    Coral Sheldon-Hess
    2/8/2019
    Incredibly simple and somewhat boring example program for running on the 
    command line
'''

print("Congratulations, you just ran a Python script from the command line!")